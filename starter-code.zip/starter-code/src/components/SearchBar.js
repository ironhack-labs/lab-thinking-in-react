import React from 'react';

const searchBar = (props) => {

  return (
    <input type="text" onChange={(e) => props.onSearch(e.target.value)}>
      {props.searchTerm}
    </input>
  )

}

export default searchBar;