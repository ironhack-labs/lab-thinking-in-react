import data from '../data.json'

import React, { Component } from 'react';
import SearchBar from './SearchBar'

class FilterableProductTable extends Component {

  constructor() {
    super()
    this.state = {
      searchTerm: ''
    }
  }

  handleSearch = (term) => {
    this.setState({
      searchTerm: term
    })
  }

  render() {

    const filteredProducts = data.filter((d) => {
      return d.name.toLowerCase().includes(this.state.searchTerm.toLowerCase())
    })

    return (
      <div>
        <SearchBar bla="blub" onSearch={this.handleSearch}></SearchBar>
        <ul>
          {filteredProducts.map((d) => {
            return <li>{d.name}</li>
          })}
        </ul>
      </div>
    );
  }
}

export default FilterableProductTable;