import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';

import FilterableProductTable from './components/FilterableProductTable'

class App extends Component {
  render() {
    return (
      <div className="App">
        <div>
          <h1>Product Store</h1>          
          <div>
            <FilterableProductTable></FilterableProductTable>
          </div>
        </div>
      </div>
    );
  }
}

export default App;
